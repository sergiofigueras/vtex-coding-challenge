# VTEX Catalog RAG com busca web

Este diretório é o pacote de especificação para construir, por meio do engine SDD/DeepSeek Harness do repositório, um RAG sobre o banco final do desafio e uma UI de busca textual. As specs começam em `ready`: este pacote define o trabalho; os comandos `project:run` é que devem produzir e verificar a implementação.

## Arquitetura-alvo

```text
navegador
  -> GET / + assets estáticos
  -> POST /api/search
servidor catalog-rag
  -> retrieval exato + FTS5 + cosine/RRF
  -> catalog.db somente leitura (evidência atual)
  -> rag.db sidecar (documentos, vetores, FTS e estado)
  -> adapters injetáveis de embedding e resposta
```

O `catalog.db` nunca é migrado ou alterado pelo RAG. O sidecar pode ser apagado e reconstruído. O browser não recebe chave, caminho de banco, prompt, vetor ou SDK de provedor. Os testes normais usam provedores falsos e não acessam a rede.

Para o catálogo observado, um documento determinístico por `Product.Id` é suficiente: `Product` e `ProductIdentity`, mais os `SellerProduct` ordenados. Como a ordem de grandeza é de mil produtos, a primeira implementação usa FTS5 e uma varredura cosseno exata sobre BLOBs `float32`; uma extensão vetorial só deve entrar depois de benchmark e spec própria.

## 1. Criar o projeto e instalar o repositório

Execute na raiz de um clone limpo:

```bash
git clone https://github.com/sergiofigueras/vtex-coding-challenge.git
cd vtex-coding-challenge

npm ci
npm --prefix projects/catalog-consolidation ci

npm run project:create -- \
  --id catalog-rag \
  --title "VTEX Catalog RAG Search UI"
```

Depois, substitua o scaffold recém-criado pelos arquivos deste pacote. `config/sources.json` deve continuar vazio: o banco final local é mutável e deve ser passado por `--catalog-db`, não registrado como fonte HTTPS pinada.

Valide a definição antes de usar qualquer modelo:

```bash
npm run project:validate -- \
  --project catalog-rag \
  --working-tree
```

## 2. Resolver a precondição de política do engine

Antes da primeira implementação que introduza adapters reais, aplique e revise a alteração descrita em [`docs/sdd/engine-policy-prerequisite.md`](docs/sdd/engine-policy-prerequisite.md). Ela resolve a divergência entre a exceção já documentada no README raiz e a regra absoluta da skill compartilhada. Isso é um bootstrap do próprio engine; o runner de projetos fica restrito a `projects/catalog-rag` e não pode editar `engine/`.

O consolidator continua estritamente model-free. Apenas adapters explicitamente exigidos por `SDD-002` e `SDD-004` podem usar rede/modelo, com fakes offline nos gates.

## 3. Preparar e executar as specs pelo framework SDD

`prepare` é model-free e cria `projects/catalog-rag/.sdd/runs/<run-id>/prompt.md`. Inspecione esse prompt antes de executar o par `run`; specs dependentes aparecem como contexto, não como autorização para ampliar escopo.

### Fundação e projeção

```bash
npm run project:prepare -- \
  --project catalog-rag \
  --change catalog-rag-foundation \
  --spec SDD-000,SDD-001 \
  --route default

npm run project:run -- \
  --project catalog-rag \
  --change catalog-rag-foundation \
  --spec SDD-000,SDD-001 \
  --route default
```

### Indexação incremental

```bash
npm run project:prepare -- \
  --project catalog-rag \
  --change catalog-rag-index \
  --spec SDD-002 \
  --route default

npm run project:run -- \
  --project catalog-rag \
  --change catalog-rag-index \
  --spec SDD-002 \
  --route default
```

### Retrieval híbrido

```bash
npm run project:prepare -- \
  --project catalog-rag \
  --change catalog-rag-retrieval \
  --spec SDD-003 \
  --route default

npm run project:run -- \
  --project catalog-rag \
  --change catalog-rag-retrieval \
  --spec SDD-003 \
  --route default
```

### Resposta grounded e API

```bash
npm run project:prepare -- \
  --project catalog-rag \
  --change catalog-rag-answer-api \
  --spec SDD-004,SDD-005 \
  --route default

npm run project:run -- \
  --project catalog-rag \
  --change catalog-rag-answer-api \
  --spec SDD-004,SDD-005 \
  --route default
```

### UI de busca

```bash
npm run project:prepare -- \
  --project catalog-rag \
  --change catalog-rag-search-ui \
  --spec SDD-006 \
  --route default

npm run project:run -- \
  --project catalog-rag \
  --change catalog-rag-search-ui \
  --spec SDD-006 \
  --route default
```

### Segurança, observabilidade e custo runtime

```bash
npm run project:prepare -- \
  --project catalog-rag \
  --change catalog-rag-runtime-operations \
  --spec SDD-007 \
  --route default

npm run project:run -- \
  --project catalog-rag \
  --change catalog-rag-runtime-operations \
  --spec SDD-007 \
  --route default
```

### Fact-check e auditoria causal do RAG

`SDD-009` especifica a validação factual de cada afirmação e testes de intervenção sobre a evidência recuperada. Seu status é `ready`: os comandos abaixo preparam ou iniciam a implementação pelo fluxo SDD; ainda não são prova de que a auditoria foi executada.

```bash
npm run project:prepare -- \
  --project catalog-rag \
  --change catalog-rag-causal-grounding-audit \
  --spec SDD-009 \
  --route default

npm run project:run -- \
  --project catalog-rag \
  --change catalog-rag-causal-grounding-audit \
  --spec SDD-009 \
  --route default
```

### Evals, browser E2E e entrega

```bash
npm run project:prepare -- \
  --project catalog-rag \
  --change catalog-rag-release \
  --spec SDD-008 \
  --route default

npm run project:run -- \
  --project catalog-rag \
  --change catalog-rag-release \
  --spec SDD-008 \
  --route default
```

Se o runner classificar a falha como rate limit HTTP 429, repita exatamente o mesmo projeto, change ID e conjunto de specs, autorizando somente o fallback configurado:

```bash
npm run project:run -- \
  --project catalog-rag \
  --change catalog-rag-answer-api \
  --spec SDD-004,SDD-005 \
  --route default \
  --rate-limit-fallback economy
```

Não use fallback para falha de teste ou de especificação. A rota `escalation` exige aprovação e razão explícitas e não faz parte do fluxo normal.

## 4. Gates depois de cada fatia

```bash
npm run project:validate -- \
  --project catalog-rag \
  --working-tree

npm --prefix projects/catalog-rag run check
npm run check
git diff --check

npm run project:cost -- \
  --project catalog-rag
```

O projeto não pertence ao workspace npm raiz. Após `SDD-000`, o Harness deve criar o `package-lock.json`, `tsconfig.json` estrito e scripts reais de build/typecheck/test/check; instale-o separadamente quando existirem:

```bash
npm --prefix projects/catalog-rag ci
```

O gate raiz valida engine, manifestos e políticas, mas não substitui o gate TypeScript do projeto.

## 5. Produzir o banco final descartável

Baixe as duas fontes pinadas do projeto existente e construa uma cópia final sob estado ignorado:

```bash
npm --prefix projects/catalog-consolidation run sources:ingest

mkdir -p projects/catalog-rag/.sdd/inputs
mkdir -p projects/catalog-rag/.sdd/runtime

cp -- \
  projects/catalog-consolidation/.sdd/inputs/catalog.db \
  projects/catalog-rag/.sdd/inputs/catalog.db

node projects/catalog-consolidation/src/cli.ts \
  --input projects/catalog-consolidation/.sdd/inputs/ProductEntry.json \
  --database projects/catalog-rag/.sdd/inputs/catalog.db \
  --format json

# Prova prática de idempotência: a segunda execução deve inserir zero linhas.
node projects/catalog-consolidation/src/cli.ts \
  --input projects/catalog-consolidation/.sdd/inputs/ProductEntry.json \
  --database projects/catalog-rag/.sdd/inputs/catalog.db \
  --format json
```

Não copie o hash da fonte original para representar esse banco final: a consolidação altera a cópia.

## 6. Indexar e abrir a UI após a implementação

Os SDDs exigem estes comandos públicos:

```bash
npm --prefix projects/catalog-rag run index -- \
  --catalog-db projects/catalog-rag/.sdd/inputs/catalog.db \
  --rag-db projects/catalog-rag/.sdd/runtime/rag.db

npm --prefix projects/catalog-rag run serve -- \
  --catalog-db projects/catalog-rag/.sdd/inputs/catalog.db \
  --rag-db projects/catalog-rag/.sdd/runtime/rag.db \
  --host 127.0.0.1 \
  --port 3000

open http://127.0.0.1:3000
```

O modo fake/offline exigido pelos testes deve ser documentado pela implementação. Para um adapter OpenAI real, forneça a chave somente no ambiente do processo, sem valor literal em comando, arquivo ou histórico:

```bash
read -s OPENAI_API_KEY
export OPENAI_API_KEY

npm --prefix projects/catalog-rag run index -- \
  --catalog-db projects/catalog-rag/.sdd/inputs/catalog.db \
  --rag-db projects/catalog-rag/.sdd/runtime/rag.db \
  --embedding-provider openai \
  --embedding-model '<modelo-configurado>'

npm --prefix projects/catalog-rag run serve -- \
  --catalog-db projects/catalog-rag/.sdd/inputs/catalog.db \
  --rag-db projects/catalog-rag/.sdd/runtime/rag.db \
  --answer-provider openai \
  --answer-model '<modelo-configurado>' \
  --host 127.0.0.1 \
  --port 3000

unset OPENAI_API_KEY
```

Os nomes concretos dos adapters e modelos devem ser pinados e registrados pela implementação de `SDD-002`/`SDD-004`; os placeholders acima não autorizam troca silenciosa.

Teste também a API sem o browser:

```bash
curl --fail-with-body \
  http://127.0.0.1:3000/api/health

curl --fail-with-body \
  -H 'Content-Type: application/json' \
  -d '{"query":"Quais produtos Lenovo aparecem no catálogo?","topK":8}' \
  http://127.0.0.1:3000/api/search
```

## 7. Evidência e custos

- `docs/sdd/manifest.json`: grafo e status das nove specs.
- `docs/sdd/traceability.json`: autoridade e propriedade recíproca dos requisitos.
- `docs/sdd/evidence-index.md`: evidência por critério; vazio enquanto as specs estão apenas `ready`.
- `projects/catalog-rag/.sdd/runs/<run-id>/`: prompts, logs e resultados privados de cada run.
- `npm run project:cost -- --project catalog-rag`: custo do Harness construindo software.
- relatório runtime exigido por `SDD-007`: custo/uso de embeddings e respostas na aplicação.

Uso desconhecido ou preço indisponível é `unavailable`, nunca zero. Não atribua chamadas da aplicação ao ledger do engine.

## Limites iniciais

O catálogo atual não fornece descrição rica, preço, estoque, compatibilidade ou avaliações. O RAG só pode responder com nome, marca, categoria, identidade canônica e sellers/SKUs existentes. Embeddings melhoram descoberta textual; não criam fatos ausentes.
